package io.kubeless;

import io.kubeless.Event;
import io.kubeless.Context;

public class Foo {
    public String foo(io.kubeless.Event event, io.kubeless.Context context) {

		System.out.println(event.Data);

		//Gson g = new Gson();
		//Num n = g.fromJson(jsonString, Num.class)

		Num n=new Num();
		n.setNum1(23);
		n.setNum2(25);

		int result =add(n.getNum1(),n.getNum2());

        return "Hello world!";
    }


    public int add(int a,int b){

		return a+b;
	}
}